import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session, flash
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'
DATABASE = 'database.db'

# ...existing code...

# Quiz list page for a specific course
@app.route('/course/<int:course_id>/quizzes')
def course_quizzes(course_id):
    if 'username' not in session:
        return redirect(url_for('login'))
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    # Get user info
    c.execute('SELECT id, role FROM users WHERE username=?', (session['username'],))
    user_row = c.fetchone()
    user_id = user_row[0]
    role = user_row[1]
    # Check enrollment
    c.execute('SELECT 1 FROM course_enrollment WHERE course_id=? AND student_id=?', (course_id, user_id))
    enrolled = c.fetchone()
    if not enrolled:
        conn.close()
        flash('You are not enrolled in this course.')
        return redirect(url_for('student_dashboard'))
    # Get quizzes for this course
    c.execute('SELECT id, name FROM quizzes WHERE course_id=?', (course_id,))
    quizzes = [{'id': row[0], 'name': row[1]} for row in c.fetchall()]
    conn.close()
    return render_template('quizzes.html', quizzes=quizzes, course_id=course_id)
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session, flash
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'
DATABASE = 'database.db'


# Initialize database
def init_db():
    if not os.path.exists(DATABASE):
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()

        # Create course_enrollment table
        c.execute('''CREATE TABLE course_enrollment (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            student_id INTEGER NOT NULL,
            FOREIGN KEY(course_id) REFERENCES courses(id),
            FOREIGN KEY(student_id) REFERENCES users(id)
        )''')
        # Create course table
        c.execute('''CREATE TABLE courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_name TEXT NOT NULL,
            teacher_id INTEGER NOT NULL,
            teacher_name TEXT NOT NULL,
            department_id INTEGER NOT NULL,
            department_name TEXT NOT NULL,
            introduction TEXT
        )''')

        # Create quiz_answers table
        c.execute('''CREATE TABLE quiz_answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user TEXT NOT NULL,
            submit_time TEXT NOT NULL,
            quiz_id INTEGER NOT NULL,
            mcq_id INTEGER NOT NULL,
            user_answer TEXT NOT NULL,
            FOREIGN KEY(quiz_id) REFERENCES quizzes(id),
            FOREIGN KEY(mcq_id) REFERENCES mcq_questions(id)
        )''')

        c.execute('''CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL,
            name TEXT NOT NULL,
            sex TEXT,
            department TEXT,
            birth_date TEXT,
            enroll_date TEXT
        )''')
        import random, datetime
        sample_id = random.randint(100000, 999999)
        c.execute("INSERT INTO users (id, username, password, role, name, sex, department, birth_date, enroll_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                  (sample_id, "testuser", "123456", "student", "Test User", "M", "Computer Science", "2000-01-01", datetime.date.today().isoformat()))

        # Create quiz table with attempts_allowed and course_id
        c.execute('''CREATE TABLE quizzes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            attempts_allowed INTEGER NOT NULL DEFAULT 1,
            course_id INTEGER NOT NULL,
            FOREIGN KEY(course_id) REFERENCES courses(id)
        )''')

        # Create quiz_attempt_history table
        c.execute('''CREATE TABLE quiz_attempt_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user TEXT NOT NULL,
            quiz_id INTEGER NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(quiz_id) REFERENCES quizzes(id)
        )''')

        # Create MCQ questions table, linked to quizzes
        c.execute('''CREATE TABLE mcq_questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            quiz_id INTEGER NOT NULL,
            question TEXT NOT NULL,
            choice_a TEXT NOT NULL,
            choice_b TEXT NOT NULL,
            choice_c TEXT NOT NULL,
            choice_d TEXT NOT NULL,
            correct_answer TEXT NOT NULL,
            FOREIGN KEY(quiz_id) REFERENCES quizzes(id)
        )''')

        # Create MCQ answers table
        c.execute('''CREATE TABLE mcq_answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user TEXT NOT NULL,
            question_id INTEGER NOT NULL,
            submitted_answer TEXT NOT NULL,
            is_correct INTEGER NOT NULL,
            FOREIGN KEY(question_id) REFERENCES mcq_questions(id)
        )''')


        # Add sample courses
        c.execute("INSERT INTO courses (course_name, teacher_id, teacher_name, department_id, department_name, introduction) VALUES (?, ?, ?, ?, ?, ?)",
                  ("Mathematics", 1001, "Dr. Smith", 10, "Science", "Intro to Mathematics"))
        c.execute("INSERT INTO courses (course_name, teacher_id, teacher_name, department_id, department_name, introduction) VALUES (?, ?, ?, ?, ?, ?)",
                  ("Physics", 1002, "Dr. Johnson", 10, "Science", "Intro to Physics"))
        c.execute("INSERT INTO courses (course_name, teacher_id, teacher_name, department_id, department_name, introduction) VALUES (?, ?, ?, ?, ?, ?)",
                  ("Chemistry", 1003, "Dr. Lee", 10, "Science", "Intro to Chemistry"))
        c.execute("INSERT INTO courses (course_name, teacher_id, teacher_name, department_id, department_name, introduction) VALUES (?, ?, ?, ?, ?, ?)",
                  ("Computer Science", 1004, "Dr. Brown", 20, "Engineering", "Intro to Computer Science"))
        c.execute("INSERT INTO courses (course_name, teacher_id, teacher_name, department_id, department_name, introduction) VALUES (?, ?, ?, ?, ?, ?)",
                  ("English", 1005, "Dr. White", 30, "Arts", "Intro to English Literature"))

        # Enroll sample student in 5 courses
        for course_id in range(1, 6):
            c.execute("INSERT INTO course_enrollment (course_id, student_id) VALUES (?, ?)", (course_id, sample_id))

        # Sample quizzes with attempts_allowed and course_id
        c.execute("INSERT INTO quizzes (name, attempts_allowed, course_id) VALUES (?, ?, ?)", ("General Knowledge", 3, 1))
        c.execute("INSERT INTO quizzes (name, attempts_allowed, course_id) VALUES (?, ?, ?)", ("Science", 2, 2))

        # Sample questions for quizzes
        c.execute("INSERT INTO mcq_questions (quiz_id, question, choice_a, choice_b, choice_c, choice_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  (1, "What is the capital of France?", "Berlin", "London", "Paris", "Rome", "c"))
        c.execute("INSERT INTO mcq_questions (quiz_id, question, choice_a, choice_b, choice_c, choice_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  (1, "Which planet is known as the Red Planet?", "Earth", "Mars", "Jupiter", "Venus", "b"))
        c.execute("INSERT INTO mcq_questions (quiz_id, question, choice_a, choice_b, choice_c, choice_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  (2, "What is H2O commonly known as?", "Salt", "Water", "Oxygen", "Hydrogen", "b"))
        c.execute("INSERT INTO mcq_questions (quiz_id, question, choice_a, choice_b, choice_c, choice_d, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  (2, "What gas do plants absorb from the atmosphere?", "Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen", "c"))

        conn.commit()
        conn.close()




# Student Dashboard page
@app.route('/student_dashboard')
def student_dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    # Get user info
    c.execute('SELECT id, role, name FROM users WHERE username=?', (session['username'],))
    user_row = c.fetchone()
    user_id = user_row[0]
    role = user_row[1]
    name = user_row[2]
    enrolled_courses = []
    if role == 'student':
        # Get enrolled courses
        c.execute('''SELECT courses.id, courses.course_name FROM courses
                    JOIN course_enrollment ON courses.id = course_enrollment.course_id
                    WHERE course_enrollment.student_id=?''', (user_id,))
        enrolled_courses = [{'id': row[0], 'name': row[1]} for row in c.fetchall()]
    conn.close()
    return render_template('student_dashboard.html', username=session['username'], name=name, enrolled_courses=enrolled_courses)


# Course homepage for students
@app.route('/course/<int:course_id>')
def course_home(course_id):
    if 'username' not in session:
        return redirect(url_for('login'))
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    # Get user info
    c.execute('SELECT id, role, name FROM users WHERE username=?', (session['username'],))
    user_row = c.fetchone()
    user_id = user_row[0]
    role = user_row[1]
    name = user_row[2]
    # Check if student is enrolled in the course
    c.execute('SELECT 1 FROM course_enrollment WHERE course_id=? AND student_id=?', (course_id, user_id))
    enrolled = c.fetchone()
    if not enrolled:
        conn.close()
        flash('You are not enrolled in this course.')
        return redirect(url_for('student_dashboard'))
    # Get course info
    c.execute('SELECT course_name, teacher_name, introduction FROM courses WHERE id=?', (course_id,))
    course_row = c.fetchone()
    course_info = {'id': course_id, 'name': course_row[0], 'teacher': course_row[1], 'intro': course_row[2]} if course_row else None
    conn.close()
    return render_template('course_home.html', course=course_info, name=name)


# Login page
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = c.fetchone()
        conn.close()
        if user:
            session['username'] = username
            # Check role and redirect
            role = user[3]
            if role == 'student':
                return redirect(url_for('student_dashboard'))
            else:
                flash('Only student dashboard is implemented.')
                return redirect(url_for('login'))
        else:
            flash('Invalid username or password')
    return render_template('login.html')




# Quiz page: show MCQs for a selected quiz
@app.route('/quiz/<int:quiz_id>', methods=['GET', 'POST'])
def quiz(quiz_id):
    if 'username' not in session:
        return redirect(url_for('login'))
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute('SELECT name, attempts_allowed FROM quizzes WHERE id=?', (quiz_id,))
    quiz_row = c.fetchone()
    quiz_name = quiz_row[0] if quiz_row else "Quiz"
    attempts_allowed = quiz_row[1] if quiz_row else 1
    # Get user's attempt history
    c.execute('SELECT attempts FROM quiz_attempt_history WHERE user=? AND quiz_id=?', (session['username'], quiz_id))
    history_row = c.fetchone()
    user_attempts = history_row[0] if history_row else 0
    c.execute('SELECT * FROM mcq_questions WHERE quiz_id=?', (quiz_id,))
    questions = [dict(id=row[0], question=row[2], choice_a=row[3], choice_b=row[4], choice_c=row[5], choice_d=row[6], correct=row[7]) for row in c.fetchall()]

    # Check for previous submission
    c.execute('SELECT submit_time FROM quiz_answers WHERE user=? AND quiz_id=? ORDER BY submit_time DESC LIMIT 1', (session['username'], quiz_id))
    prev = c.fetchone()
    prev_submit_time = prev[0] if prev else None
    show_quiz = False
    feedback = []
    prev_answers = []

    # If user chooses to view previous submission
    if request.method == 'POST' and request.form.get('action') == 'view_previous':
        # Get previous answers
        c.execute('SELECT mcq_id, user_answer FROM quiz_answers WHERE user=? AND quiz_id=? AND submit_time=?', (session['username'], quiz_id, prev_submit_time))
        ans_map = {row[0]: row[1] for row in c.fetchall()}
        for idx, q in enumerate(questions, start=1):
            user_ans = ans_map.get(q['id'], '')
            is_correct = int(user_ans == q['correct']) if user_ans else 0
            result = 'Correct' if is_correct else 'Incorrect or not answered'
            prev_answers.append({'index': idx, 'question': q['question'], 'user_answer': user_ans, 'result': result})

    # If user chooses to do quiz
    elif request.method == 'POST' and request.form.get('action') == 'do_again':
        # Check if user can attempt
        if user_attempts < attempts_allowed:
            show_quiz = True
            # Update or insert attempt history
            if history_row:
                c.execute('UPDATE quiz_attempt_history SET attempts = attempts + 1 WHERE user=? AND quiz_id=?', (session['username'], quiz_id))
            else:
                c.execute('INSERT INTO quiz_attempt_history (user, quiz_id, attempts) VALUES (?, ?, 1)', (session['username'], quiz_id))
            conn.commit()
        else:
            show_quiz = False
            feedback.append({'index': '', 'result': f'You have reached the maximum allowed attempts ({attempts_allowed}) for this quiz.'})

    # If user submits new answers
    elif request.method == 'POST' and request.form.get('action') == 'submit':
        import datetime
        submit_time = datetime.datetime.now().isoformat()
        show_quiz = False
        for idx, q in enumerate(questions, start=1):
            ans = request.form.get(f'answer_{q["id"]}')
            c.execute('INSERT INTO quiz_answers (user, submit_time, quiz_id, mcq_id, user_answer) VALUES (?, ?, ?, ?, ?)',
                      (session['username'], submit_time, quiz_id, q['id'], ans if ans else ''))
            is_correct = int(ans == q['correct']) if ans else 0
            result = 'Correct' if is_correct else 'Incorrect or not answered'
            feedback.append({'index': idx, 'result': result})
        conn.commit()

    conn.close()
    return render_template('mcq.html', questions=questions, feedback=feedback, quiz_name=quiz_name, prev_submit_time=prev_submit_time, show_quiz=show_quiz, prev_answers=prev_answers, attempts_allowed=attempts_allowed, user_attempts=user_attempts)


# Quiz list page: show all quizzes
@app.route('/quizzes')
def quizzes():
    if 'username' not in session:
        return redirect(url_for('login'))
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute('SELECT id, name FROM quizzes')
    quizzes = [{'id': row[0], 'name': row[1]} for row in c.fetchall()]
    conn.close()
    return render_template('quizzes.html', quizzes=quizzes)

# Logout
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
